# So-Chat-Commander
Chat Commander is a client side Chrome extension that integrates commands for your use.  

So far there are three commands here

- /collapse
- /uncollapse
- /giphy <Phrase/Word>
- /shruggie

So collapse and uncollapse are self-explanatory, they take any onebox chat message (Wikipedia, SO Question/Answer,  Youtube, Image, etc.)

/giphy will send a Gifs to the chat according to anything you send after it.
